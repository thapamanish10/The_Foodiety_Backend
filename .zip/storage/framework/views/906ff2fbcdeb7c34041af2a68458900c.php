<?php
    $unvisitedMessageCount = App\Models\Message::where('status', 'unvisited')->count();
?>
<aside>
    <div class="sidebarContainer">
        <a href="#">
            <img src="<?php echo e(asset('dashboardicons/logo.png')); ?>" alt="Logo">
        </a>
    </div>
    <div class="sidebarNavItems">
        <ul>
            <li class="<?php echo e(Request::is('admin/dashboard') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(url('/admin/dashboard')); ?>">
                <img src="<?php echo e(asset('db.png')); ?>" alt="HomeIcon">
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('/') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('home-agreement.png')); ?>" alt="HomeIcon">
                    <span>Home</span>
                </a>
            </li>
            <h3 class="sidebarSubHeading store">Home</h3>
            <li class="<?php echo e(Request::is('carousel') ? 'activeNavLink' : ''); ?>">
                <a  href="<?php echo e(url('/carousel')); ?>">
                <img src="<?php echo e(asset('carousel.png')); ?>" alt="CarouselIcon">
                    <span>Carousel</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('business') ? 'activeNavLink' : ''); ?>">
                <a  href="<?php echo e(url('/business')); ?>">
                <img src="<?php echo e(asset('info.png')); ?>" alt="AboutIcon">
                    <span>About</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('services') ? 'activeNavLink' : ''); ?>">
                <a  href="<?php echo e(url('/services')); ?>">
                <img src="<?php echo e(asset('24-hours.png')); ?>" alt="AboutIcon">
                    <span>Services</span>
                </a>
            </li>
            <h3 class="sidebarSubHeading store">Manage Users</h3>
            <li class="<?php echo e(Request::is('users') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(route('users.index')); ?>" class="nav-link">
                    <img src="<?php echo e(asset('add (1).png')); ?>" alt="Blog Icon" class="nav-icon">
                    <span>Users</span>
                </a>
            </li>
            <h3 class="sidebarSubHeading store">Categories</h3>
            <li class="<?php echo e(Request::is('categories') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(route('categories.index')); ?>" class="nav-link">
                    <img src="<?php echo e(asset('menu.png')); ?>" alt="Blog Icon" class="nav-icon">
                    <span>Categories</span>
                </a>
            </li>
            <h3 class="sidebarSubHeading store">Services</h3>
            <li class="<?php echo e(Request::is('restaurants') ? 'activeNavLink' : ''); ?>">
                <a  href="<?php echo e(url('/restaurants')); ?>">
                <img src="<?php echo e(asset('restaurant.png')); ?>" alt="ProductIcon">
                    <span>Restaurants</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('blogs') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(url('/blogs')); ?>" class="nav-link">
                    <img src="<?php echo e(asset('trending.png')); ?>" alt="Blog Icon" class="nav-icon">
                    <span>Blogs</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('recipes') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(url('/recipes')); ?>" class="nav-link">
                    <img src="<?php echo e(asset('ingredients.png')); ?>" alt="Blog Icon" class="nav-icon">
                    <span>Recipes</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('galleries') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(route('galleries.index')); ?>" class="nav-link">
                    <img src="<?php echo e(asset('apple.png')); ?>" alt="Blog Icon" class="nav-icon">
                    <span>Galleries</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('ais') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(route('ais.index')); ?>" class="nav-link">
                    <img src="<?php echo e(asset('magic-wand.png')); ?>" alt="Blog Icon" class="nav-icon">
                    <span>Foodiety AI</span>
                </a>
            </li>
            <li class="<?php echo e(Request::is('videos') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(route('videos.index')); ?>" class="nav-link">
                    <img src="<?php echo e(asset('streaming.png')); ?>" alt="Blog Icon" class="nav-icon">
                    <span>Videos</span>
                </a>
            </li>


            <li class="<?php echo e(Request::is('messages') ? 'activeNavLink' : ''); ?>">
                <a href="<?php echo e(url('/messages')); ?>">
                <img src="<?php echo e(asset('comment.png')); ?>" alt="ChatIcon">
                    <span>Messages</span>
                </a>
                
                <?php if($unvisitedMessageCount > 0): ?>
                    <div class="messageNum"><?php echo e($unvisitedMessageCount); ?></div>
                <?php endif; ?>
            </li>

            
            <div class="sideBarProfile">
                <h3 class="sidebarSubHeading">Profile / Account</h3>
                <li class="<?php echo e(Request::is('profile') ? 'activeNavLink' : ''); ?>">
                    <a  href="<?php echo e(url('/profile')); ?>">
                    <img src="<?php echo e(asset('profile.png')); ?>" alt="ProfileIcon">
                        <span>Profile</span>
                    </a>
                </li>
                
                <li class="<?php echo e(Request::is('setting') ? 'activeNavLink' : ''); ?>">
                    <a  href="<?php echo e(url('/setting')); ?>">
                    <img src="<?php echo e(asset('settings.png')); ?>" alt="manageIcon">
                        <span>Settings</span>
                    </a>
                </li>
            </div>
            
            <div class="logoutButton">
                <h3 class="sidebarSubHeading">Logout / Exit</h3>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                <li id="logout">
                    <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <img src="<?php echo e(asset('power-off (1).png')); ?>" alt="BlogIcon">
                        <span>Logout</span>
                    </a>
                </li>
            </div>
        </ul>
    </div>
</aside>
<?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>