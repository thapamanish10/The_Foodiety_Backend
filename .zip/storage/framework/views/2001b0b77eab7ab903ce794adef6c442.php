<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Foodiety/Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('./css/auth.css')); ?>">
</head>
<body>
    <div class="authContainer">
        <div class="authContainerCard">
        <div class="authHeading">
            <h2 class="authHeadingText">Login</h2>
        </div>

        <div class="authFormContainer">
            <form class="authForm" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <label class="form-label" for="email" class="">Email</label>
                <div class="authFormGroup">
                    <div class="inputBoxImage">
                        <img class="inputBoxImg" src="<?php echo e(url('dashboardicons/mail.png')); ?>" alt="MailIcon">
                    </div>
                    <div class="inputBox">
                        <input id="email" name="email" type="email" autocomplete="email" required autofocus  >
                    </div>
                </div>
                <label class="form-label" for="password" >Password</label>
                <div class="authFormGroup">
                    <div class="inputBoxImage">
                        <img class="inputBoxImg" src="<?php echo e(url('dashboardicons/eye.png')); ?>" alt="EyeArrowIcon">
                    </div>
                    <div class="inputBox">
                        <input id="password" 
                            name="password" 
                            type="password" 
                            autocomplete="current-password" 
                            required />
                        </div>
                    </div>
                </div>
                
                <!-- Remember Me -->
                <div class="authFormRememberME">
                    <div class="authForgotPassword">
                        <?php if(Route::has('password.request')): ?>
                            <a href="<?php echo e(route('password.request')); ?>">Forgot password?</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="authFormGroupButton">
                    <button type="submit" class="">Log in</button>
                </div>
                <a href="<?php echo e(route('register')); ?>" class="authNavigation">Don't have an account? <span>Sign Up here</span></a>
            </div>
            </form>
        </div>
        </div>
        </div>
</body>
</html><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/auth/login.blade.php ENDPATH**/ ?>