<nav>
    <div class="navLeft">
        <h3 class="loggedInUserName">
            
        </h3>
        <span class="span">Monday, 23 November</span>
    </div>
    <div class="navRight">
        <div class="search">
            <img src="<?php echo e(asset('dashboardicons/search.png')); ?>" class="SearchIcon" alt="SearchIcon">
            <input type="text" placeholder="Search...">
        </div>
        <div class="userProfile" id="profileButton">
            
                <img src="<?php echo e(asset('assets/profile.png')); ?>" alt="User Profile">
            
            
        </div>
    </div>
</nav>

<?php $__env->startSection('javascript'); ?>
    <script>
        const profileButton = document.getElementById('profileButton');
        const profileDropdown = document.getElementById('profileDropdown');

        const toggleDropdown = (event) => {
            event.preventDefault();
            event.stopPropagation();
            if (profileDropdown.style.display === 'none' || profileDropdown.style.display === '') {
                profileDropdown.style.display = 'block';
            } else {
                profileDropdown.style.display = 'none';
            }
        };

        profileButton.addEventListener('click', toggleDropdown);

        document.addEventListener('click', (event) => {
            if (!profileButton.contains(event.target) && !profileDropdown.contains(event.target)) {
                profileDropdown.style.display = 'none';
            }
        });
    </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/layouts/topbar.blade.php ENDPATH**/ ?>