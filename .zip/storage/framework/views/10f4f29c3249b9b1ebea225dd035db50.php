

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.loading-screen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="container-heading">
            <h3>Reset Password for: <?php echo e($user->name); ?></h3>
            <p>Provide information about the user.</p>
        </div>

        <form method="POST" action="<?php echo e(route('users.reset-password.update', $user)); ?>" id="blogForm">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="password">New Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>

            <div class="form-group">
                <label for="password_confirmation">Confirm Password</label>
                <input type="password" class="form-control" id="password_confirmation" name="password_confirmation"
                    required>
            </div>
            <br>
            <div class="form-group-buttons">
                <a href="<?php echo e(route('users.index')); ?>" class="btn-secondary">Cancel</a>
                <button type="submit" id="submitButton" class="btn-primary">Reset Password</button>
            </div>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('blogForm');
            const loadingOverlay = document.getElementById('loadingOverlay');
            const submitButton = document.getElementById('submitButton');

            form.addEventListener('submit', function(e) {
                // Show loading spinner
                loadingOverlay.style.display = 'flex';

                // Disable submit button to prevent multiple submissions
                if (submitButton) {
                    submitButton.disabled = true;
                    submitButton.innerHTML = 'Processing...';
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/users/reset-password.blade.php ENDPATH**/ ?>