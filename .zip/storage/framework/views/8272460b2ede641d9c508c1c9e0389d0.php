<?php
    $blogs = \App\Models\Blog::withCount(['likes', 'comments', 'views', 'images'])
        ->orderBy('created_at', 'desc')
        ->get();
?>
<div class="home-blog-container">
    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $attributes; } ?>
<?php $component = App\View\Components\Card::resolve(['blog' => $blog,'views' => $blog->views,'comments' => $blog->comments,'type' => 'blog'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['likes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blog->likes)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $attributes = $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>no blogs found</p>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal1d635ff5d0ced99ae72db996b073831a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1d635ff5d0ced99ae72db996b073831a = $attributes; } ?>
<?php $component = App\View\Components\CardLink::resolve(['route' => 'home.blogs.index'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CardLink::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1d635ff5d0ced99ae72db996b073831a)): ?>
<?php $attributes = $__attributesOriginal1d635ff5d0ced99ae72db996b073831a; ?>
<?php unset($__attributesOriginal1d635ff5d0ced99ae72db996b073831a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1d635ff5d0ced99ae72db996b073831a)): ?>
<?php $component = $__componentOriginal1d635ff5d0ced99ae72db996b073831a; ?>
<?php unset($__componentOriginal1d635ff5d0ced99ae72db996b073831a); ?>
<?php endif; ?>
</div>
<style>
    .home-blog-container {
        width: 100%;
        margin: auto;
        height: fit-content;
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 15px;
        padding: 20px 0;
    }

    @media (max-width: 1200px) {
        .home-blog-container {
            grid-template-columns: repeat(3, 1fr);
        }
    }

    @media (max-width: 900px) {
        .home-blog-container {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 600px) {
        .home-blog-container {
            grid-template-columns: repeat(2, 1fr);
            gap: 0.5rem;
        }
    }
</style>
<?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/Frontend/blogs/home-blog.blade.php ENDPATH**/ ?>