<?php
    $services = App\Models\Service::orderBy('created_at', 'desc')->get();
?>
<div class="home-service-container">
    <img class="bg-image" src="<?php echo e(url('ww.jpg')); ?>" alt="">
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginalb27a5a249f71ab571a403abfa68dc52f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb27a5a249f71ab571a403abfa68dc52f = $attributes; } ?>
<?php $component = App\View\Components\ServiceCard::resolve(['service' => $service,'type' => 'clickable','link' => route('home.services.show', $service->id)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ServiceCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb27a5a249f71ab571a403abfa68dc52f)): ?>
<?php $attributes = $__attributesOriginalb27a5a249f71ab571a403abfa68dc52f; ?>
<?php unset($__attributesOriginalb27a5a249f71ab571a403abfa68dc52f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb27a5a249f71ab571a403abfa68dc52f)): ?>
<?php $component = $__componentOriginalb27a5a249f71ab571a403abfa68dc52f; ?>
<?php unset($__componentOriginalb27a5a249f71ab571a403abfa68dc52f); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<style>
    .home-service-container {
        width: 100%;
        margin: auto;
        height: fit-content;
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        gap: 15px;
        padding: 20px 0;
        position: relative;
        overflow: hidden;
    }

    .home-service-container .bg-image {
        width: 100%;
        height: 100%;
        position: absolute;
        object-fit: cover;
    }

    @media (max-width: 1200px) {
        .home-service-container {
            grid-template-columns: repeat(3, 1fr);
        }
    }

    @media (max-width: 900px) {
        .home-service-container {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 600px) {
        .home-service-container {
            height: max-content;
            grid-template-columns: repeat(2, 1fr);
            gap: 0.5rem;
        }
    }
</style>
<?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/Frontend/services/home-service.blade.php ENDPATH**/ ?>