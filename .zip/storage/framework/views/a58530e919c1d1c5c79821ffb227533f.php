<?php $__env->startSection('content'); ?>
    <section class="main-blog-detail-div">
        <br>
        <br>
        <br>
        <?php if (isset($component)) { $__componentOriginal4f9d38156909c30c7bc179d14c0a96c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4 = $attributes; } ?>
<?php $component = App\View\Components\MainSubHeading::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-sub-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainSubHeading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4)): ?>
<?php $attributes = $__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4; ?>
<?php unset($__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f9d38156909c30c7bc179d14c0a96c4)): ?>
<?php $component = $__componentOriginal4f9d38156909c30c7bc179d14c0a96c4; ?>
<?php unset($__componentOriginal4f9d38156909c30c7bc179d14c0a96c4); ?>
<?php endif; ?>
        <div class="main-blog-detail-div-card">
            <?php if (isset($component)) { $__componentOriginal50bd57e35581bb686fde81b3a43412c9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50bd57e35581bb686fde81b3a43412c9 = $attributes; } ?>
<?php $component = App\View\Components\UserInfo::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\UserInfo::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50bd57e35581bb686fde81b3a43412c9)): ?>
<?php $attributes = $__attributesOriginal50bd57e35581bb686fde81b3a43412c9; ?>
<?php unset($__attributesOriginal50bd57e35581bb686fde81b3a43412c9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50bd57e35581bb686fde81b3a43412c9)): ?>
<?php $component = $__componentOriginal50bd57e35581bb686fde81b3a43412c9; ?>
<?php unset($__componentOriginal50bd57e35581bb686fde81b3a43412c9); ?>
<?php endif; ?>
            <h2 class="main-blog-detail-div-heading"><?php echo e($blog->name); ?></h2>
            <p class="main-blog-detail-div-desc">
                <?php echo $blog->desc; ?>

            </p>

            <!-- Image Carousel -->
            <div class="main-blog-detail-div-card-image">
                <?php if($blog->images->count() > 0): ?>
                    <div class="blog-carousel">
                        <?php $__currentLoopData = $blog->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-slide">
                                <img src="<?php echo e(asset('storage/' . $image->path)); ?>" alt="<?php echo e($blog->name); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- Clone first image for infinite effect -->
                        <?php if($blog->images->count() > 1): ?>
                            <div class="carousel-slide">
                                <img src="<?php echo e(asset('storage/' . $blog->images->first()->path)); ?>" alt="<?php echo e($blog->name); ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if($blog->images->count() > 1): ?>
                        <div class="carousel-controls">
                            <button class="carousel-prev">&lt;</button>
                            <button class="carousel-next">&gt;</button>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <img src="<?php echo e(asset('images/default-blog.jpg')); ?>" alt="No image">
                <?php endif; ?>
            </div>
            <p class="main-blog-detail-div-desc">
                <?php echo $blog->desc2; ?>

            </p>
            <div class="main-blog-detail-div-info">
                <div class="main-blog-detail-div-info-sec">
                    <div class="main-blog-detail-div-info-sub-sec share-social-links">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>"
                            target="_blank">
                            <img src="<?php echo e(asset('facebook-app-symbol.png')); ?>" alt="Share on Facebook">
                        </a>
                    </div>
                    <div class="main-blog-detail-div-info-sub-sec share-social-links">
                        <a href="https://www.instagram.com/?url=<?php echo e(urlencode(url()->current())); ?>" target="_blank" title="Share on Instagram">
                            <img src="<?php echo e(url('instagram (3).png')); ?>" alt="Share on Instagram">
                        </a>
                    </div>
                    <div class="main-blog-detail-div-info-sub-sec share-social-links"
                        onclick="copyToClipboard('<?php echo e(url()->current()); ?>')">
                        <img src="<?php echo e(asset('link.png')); ?>" alt="Copy link">
                    </div>
                </div>
            </div>

            <div class="main-blog-detail-div-info">
                <div class="main-blog-detail-div-info-sec">
                    <div class="main-blog-detail-div-info-sub-sec">
                        <span><?php echo e($viewCount); ?> views</span>
                    </div>
                    <div class="main-blog-detail-div-info-sub-sec">
                        <span><?php echo e($commentCount); ?> comments</span>
                    </div>
                </div>
                <div class="main-blog-detail-div-info-sec">
                    <form action="<?php echo e(route('blogs.like', $blog)); ?>" method="POST" class="like-form">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="like-button <?php echo e($blog->isLikedBy(auth()->user()) ? 'liked' : ''); ?>">
                            <div class="main-blog-detail-div-info-sub-sec">
                                <span><?php echo e($likeCount); ?></span>
                                <img src="<?php echo e(asset($blog->isLikedBy(auth()->user()) ? 'heart (2).png' : 'heart (1).png')); ?>"
                                    alt="Like">
                            </div>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginalc769a969ca98d1e8e0ac150f205759fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc769a969ca98d1e8e0ac150f205759fd = $attributes; } ?>
<?php $component = App\View\Components\AddComment::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('add-comment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AddComment::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['comments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blog->comments),'blog_id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blog->id)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc769a969ca98d1e8e0ac150f205759fd)): ?>
<?php $attributes = $__attributesOriginalc769a969ca98d1e8e0ac150f205759fd; ?>
<?php unset($__attributesOriginalc769a969ca98d1e8e0ac150f205759fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc769a969ca98d1e8e0ac150f205759fd)): ?>
<?php $component = $__componentOriginalc769a969ca98d1e8e0ac150f205759fd; ?>
<?php unset($__componentOriginalc769a969ca98d1e8e0ac150f205759fd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginald3cddfb27413632ea85f319788e72513 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3cddfb27413632ea85f319788e72513 = $attributes; } ?>
<?php $component = App\View\Components\SeeAllHeading::resolve(['route' => 'home.blogs.index'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('see-all-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SeeAllHeading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3cddfb27413632ea85f319788e72513)): ?>
<?php $attributes = $__attributesOriginald3cddfb27413632ea85f319788e72513; ?>
<?php unset($__attributesOriginald3cddfb27413632ea85f319788e72513); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3cddfb27413632ea85f319788e72513)): ?>
<?php $component = $__componentOriginald3cddfb27413632ea85f319788e72513; ?>
<?php unset($__componentOriginald3cddfb27413632ea85f319788e72513); ?>
<?php endif; ?>
        <?php echo $__env->make('Frontend.blogs.recent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap');

    .main-blog-detail-div-info-sec button {
        background: transparent;
        border: 0;
        outline: 0;
    }

    .main-blog-detail-div {
        width: 55%;
        margin: auto;
        height: fit-content;
    }

    .main-blog-detail-div-card {
        padding: 3rem;
        border: 1px solid #ddd;
    }

    
    /* Carousel Styles */
    .main-blog-detail-div-card-image {
        width: 100%;
        height: 450px;
        position: relative;
        overflow: hidden;
        margin: 2rem 0;
    }

    .blog-carousel {
        display: flex;
        width: 100%;
        height: 100%;
    }

    .carousel-slide {
        min-width: 100%;
        height: 100%;
        flex-shrink: 0;
        transition: transform 0.5s ease;
    }

    .carousel-slide img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .carousel-controls {
        position: absolute;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        display: flex;
        gap: 10px;
        z-index: 3;
        display: none;
    }

    .carousel-prev,
    .carousel-next {
        background: rgba(255, 255, 255, 0.7);
        border: none;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-weight: bold;
        font-size: 1.2rem;
    }

    .main-blog-detail-div-card p {
        width: 100%;
        margin: auto;
        font-size: 17px;
        font-weight: 400;
        text-align: justify !important;
        color: #5f5f5f;
        line-height: 1.5;
    }

    .main-blog-detail-div-info {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-top: 1.5px solid #dddddd;
        z-index: 5;
    }

    .main-blog-detail-div-info-sec {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem 0;
    }

    .main-blog-detail-div-info-sub-sec {
        display: flex;
        align-items: center;
        gap: .5rem;
    }

    .main-blog-detail-div-info-sub-sec img {
        width: 20px;
        height: 20px;
        object-fit: cover;
        cursor: pointer;
    }

    .main-blog-detail-div-info-sub-sec span {
        font-size: 15px;
        font-weight: normal;
        color: #5f5f5f;
    }

    .share-social-links {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1.5px solid #ddd;
        cursor: pointer;
    }

    .share-social-links img {
        width: 50%;
        height: 50%;
        margin: auto;
        object-fit: cover;
    }

    .share-social-links a {
        display: flex;
    }

    @media (max-width: 768px) {
        .main-blog-detail-div {
            width: 100%;
            margin: auto;
            height: fit-content;
        }

        .main-blog-detail-div-card {
            padding: 1.5rem;
            border: 1px solid #ddd;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize infinite carousel
        const carousel = document.querySelector('.blog-carousel');
        if (carousel && carousel.children.length > 1) {
            const slides = carousel.children;
            const totalSlides = slides.length - 1; // Subtract 1 for the cloned slide
            let currentIndex = 0;
            let isTransitioning = false;

            // Set initial position
            carousel.style.transform = 'translateX(0)';

            // Auto-scroll every 3 seconds (right to left)
            const interval = setInterval(() => {
                if (!isTransitioning) {
                    goToNextSlide();
                }
            }, 3000);

            function goToNextSlide() {
                isTransitioning = true;
                currentIndex++;
                carousel.style.transition = 'transform 0.5s ease';
                carousel.style.transform = `translateX(-${currentIndex * 100}%)`;
            }

            function goToPrevSlide() {
                isTransitioning = true;
                currentIndex--;
                carousel.style.transition = 'transform 0.5s ease';
                carousel.style.transform = `translateX(-${currentIndex * 100}%)`;
            }

            // Handle transition end
            carousel.addEventListener('transitionend', () => {
                isTransitioning = false;

                // If at the clone (last slide), instantly jump to the real first slide
                if (currentIndex >= totalSlides) {
                    carousel.style.transition = 'none';
                    currentIndex = 0;
                    carousel.style.transform = 'translateX(0)';
                }
                // If at the first slide going backward, jump to the last real slide
                else if (currentIndex < 0) {
                    carousel.style.transition = 'none';
                    currentIndex = totalSlides - 1;
                    carousel.style.transform = `translateX(-${currentIndex * 100}%)`;
                }
            });

            // Navigation buttons
            const prevBtn = document.querySelector('.carousel-prev');
            const nextBtn = document.querySelector('.carousel-next');

            if (prevBtn && nextBtn) {
                prevBtn.addEventListener('click', () => {
                    clearInterval(interval);
                    goToPrevSlide();
                });

                nextBtn.addEventListener('click', () => {
                    clearInterval(interval);
                    goToNextSlide();
                });
            }
        }

        // Copy link functionality
        window.copyToClipboard = function(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('Link copied to clipboard!');
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        };
    });
</script>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/Frontend/blogs/show.blade.php ENDPATH**/ ?>