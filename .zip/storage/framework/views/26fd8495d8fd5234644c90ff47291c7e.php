

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3 = $attributes; } ?>
<?php $component = App\View\Components\MainHeading::resolve(['title' => 'Photos'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainHeading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3)): ?>
<?php $attributes = $__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3; ?>
<?php unset($__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3)): ?>
<?php $component = $__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3; ?>
<?php unset($__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3); ?>
<?php endif; ?>
    <section class="gallery-main-div">
        <div class="gallery-main-div-card">
            <div class="gallery-main-div-card-body">
                <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if (isset($component)) { $__componentOriginal5ba7af1978cb32661e61212e371df1e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ba7af1978cb32661e61212e371df1e2 = $attributes; } ?>
<?php $component = App\View\Components\GallaryCard::resolve(['gallery' => $gallery,'link' => ''.e(route('home.galleries.show', ['gallery' => $gallery->id . '-' . $gallery->name])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('gallary-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GallaryCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ba7af1978cb32661e61212e371df1e2)): ?>
<?php $attributes = $__attributesOriginal5ba7af1978cb32661e61212e371df1e2; ?>
<?php unset($__attributesOriginal5ba7af1978cb32661e61212e371df1e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ba7af1978cb32661e61212e371df1e2)): ?>
<?php $component = $__componentOriginal5ba7af1978cb32661e61212e371df1e2; ?>
<?php unset($__componentOriginal5ba7af1978cb32661e61212e371df1e2); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php if (isset($component)) { $__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3 = $attributes; } ?>
<?php $component = App\View\Components\MainHeading::resolve(['title' => 'Videos'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainHeading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3)): ?>
<?php $attributes = $__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3; ?>
<?php unset($__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3)): ?>
<?php $component = $__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3; ?>
<?php unset($__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3); ?>
<?php endif; ?>
    <section class="gallery-main-div">
        <div class="gallery-main-div-card">
            <div class="gallery-main-div-card-body">
                <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if (isset($component)) { $__componentOriginal02a086c3ac88c4ed18a5d5fd982af3c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal02a086c3ac88c4ed18a5d5fd982af3c7 = $attributes; } ?>
<?php $component = App\View\Components\VideoCard::resolve(['video' => $video] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('video-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\VideoCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal02a086c3ac88c4ed18a5d5fd982af3c7)): ?>
<?php $attributes = $__attributesOriginal02a086c3ac88c4ed18a5d5fd982af3c7; ?>
<?php unset($__attributesOriginal02a086c3ac88c4ed18a5d5fd982af3c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal02a086c3ac88c4ed18a5d5fd982af3c7)): ?>
<?php $component = $__componentOriginal02a086c3ac88c4ed18a5d5fd982af3c7; ?>
<?php unset($__componentOriginal02a086c3ac88c4ed18a5d5fd982af3c7); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <style>
        .gallery-main-div {
            width: 100%;
            height: auto;
            min-height: 100vh;
        }

        .gallery-main-div-card-body {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            padding: 1rem;
        }

        @media (max-width: 1200px) {
            .gallery-main-div-card-body {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 900px) {
            .gallery-main-div-card-body {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .gallery-main-div-card-body {
                grid-template-columns: repeat(2, 1fr);
                gap: .5rem;
                padding: .5rem;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/Frontend/gallery/index.blade.php ENDPATH**/ ?>