<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['comments', 'blog_id']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['comments', 'blog_id']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<section class="add-comment-main-div">
    <div class="add-comment-main-div-heading">
        <h3>Comments</h3>
    </div>
    <div class="add-comment-main-div-body">
        <form action="<?php echo e($type === 'recipe' ? route('recipes.comment', $blog_id) : 
            ($type === 'restaurant' ? route('restaurants.comment', $blog_id) : 
            route('blogs.comment', $blog_id))); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <textarea name="content" cols="30" rows="10" placeholder="Write a comment ..."></textarea>
            <input type="hidden" name="parent_id" value="<?php echo e($parentId ?? null); ?>">
            <div class="add-comment-main-div-body-sub-section">
                <?php if(auth()->guard()->guest()): ?>
                    <p>Log in to publish as a member</p>
                <?php endif; ?>
                <div class="add-comment-main-div-body-sub-section-btns">
                    <button type="button" class="cancle">Cancel</button>
                    <button type="submit" class="publish" <?php if(auth()->guard()->guest()): ?> disabled <?php endif; ?>>Publish</button>
                </div>
            </div>
        </form>
    </div>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal1b0e72f2d617457fd8b72d32acd2bee7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b0e72f2d617457fd8b72d32acd2bee7 = $attributes; } ?>
<?php $component = App\View\Components\Comment::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('comment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Comment::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['comment' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($comment)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b0e72f2d617457fd8b72d32acd2bee7)): ?>
<?php $attributes = $__attributesOriginal1b0e72f2d617457fd8b72d32acd2bee7; ?>
<?php unset($__attributesOriginal1b0e72f2d617457fd8b72d32acd2bee7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b0e72f2d617457fd8b72d32acd2bee7)): ?>
<?php $component = $__componentOriginal1b0e72f2d617457fd8b72d32acd2bee7; ?>
<?php unset($__componentOriginal1b0e72f2d617457fd8b72d32acd2bee7); ?>
<?php endif; ?>

        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap');

    .add-comment-main-div {
        width: 100%;
        height: auto;
        border: 1px solid #ddd;
        padding: 2rem 0;
        margin: 4rem 0;
    }

    .add-comment-main-div-heading {
        width: 90%;
        margin: auto;
        padding: 1rem 0;
        border-bottom: 1.5px solid #ddd;
    }

    .add-comment-main-div-heading h3 {
        width: 100%;
        margin: auto;
        font-family: "Playfair Display", serif !important;
        font-weight: 400;
        color: #5f5f5f;
    }

    .add-comment-main-div-body {
        width: 90%;
        margin: 2rem auto;
    }

    .add-comment-main-div-body textarea {
        width: 100%;
        height: 100px;
        border: 1.5px solid #ddd;
        outline: 0;
        font-family: "Playfair Display", serif !important;
        padding: 1rem;
    }

    .add-comment-main-div-body-sub-section {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        margin: 1rem 0;
    }

    .add-comment-main-div-body-sub-section P {
        font-size: 15px;
        font-weight: 400;
        font-family: "Playfair Display", serif !important;
    }

    .add-comment-main-div-body-sub-section-btns {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 1rem;
    }

    .add-comment-main-div-body-sub-section-btns button {
        padding: 5px 7px;
        border: 0;
        outline: 0;
        cursor: pointer;
        font-size: 15px;
        font-weight: 400;
        font-family: "Playfair Display", serif !important;
        background: transparent;
    }

    .add-comment-main-div-body-sub-section-btns button:active {
        opacity: 0.7;
    }

    .add-comment-main-div-body-sub-section-btns .publish {
        background: #ffde59;
        color: #5f5f5f;
    }

    @media (max-width: 768px) {
        .add-comment-main-div {
            width: 100%;
            height: auto;
            border: 1px solid #ddd;
            padding: 0;
            margin: 4rem 0;
        }

        .add-comment-main-div-heading {
            width: 90%;
            margin: auto;
            padding: 1rem 0;
            border-bottom: 1.5px solid #ddd;
        }

        .add-comment-main-div-body {
            width: 90%;
            margin: 2rem auto;
        }

        .add-comment-main-div-body textarea {
            width: 100%;
            height: 100px;
            border: 1.5px solid #ddd;
            outline: 0;
            font-family: "Playfair Display", serif !important;
        }
    }
</style>
<?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/components/add-comment.blade.php ENDPATH**/ ?>