<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('Frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<style>
body, html {
    margin: 0;
    padding: 0;
    width: 100%;
    overflow-x: hidden; 
    /* background: #f8f8ff93; */
}
</style>

<body class="<?php echo e($bodyClass ?? ''); ?>">
    <?php echo $__env->make('Frontend.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
            <?php if (isset($component)) { $__componentOriginalc127e384cf9407522ed042a2ed5a3cfb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc127e384cf9407522ed042a2ed5a3cfb = $attributes; } ?>
<?php $component = App\View\Components\LoadingScreen::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loading-screen'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LoadingScreen::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc127e384cf9407522ed042a2ed5a3cfb)): ?>
<?php $attributes = $__attributesOriginalc127e384cf9407522ed042a2ed5a3cfb; ?>
<?php unset($__attributesOriginalc127e384cf9407522ed042a2ed5a3cfb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc127e384cf9407522ed042a2ed5a3cfb)): ?>
<?php $component = $__componentOriginalc127e384cf9407522ed042a2ed5a3cfb; ?>
<?php unset($__componentOriginalc127e384cf9407522ed042a2ed5a3cfb); ?>
<?php endif; ?>
        </main>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Restore scroll position
            const scrollPosition = sessionStorage.getItem('scrollPosition');
            if (scrollPosition) {
                requestAnimationFrame(() => {
                    window.scrollTo(0, parseInt(scrollPosition));
                    sessionStorage.removeItem('scrollPosition');
                });
            }

            // Debounce function to limit how often we save position
            let saveScrollTimeout;
            const saveScrollPosition = () => {
                clearTimeout(saveScrollTimeout);
                saveScrollTimeout = setTimeout(() => {
                    sessionStorage.setItem('scrollPosition', window.scrollY || window.pageYOffset);
                }, 100);
            };

            window.addEventListener('scroll', saveScrollPosition);

            window.addEventListener('beforeunload', saveScrollPosition);
        });
    </script>
    <?php echo $__env->make('Frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/Frontend/layouts/main.blade.php ENDPATH**/ ?>