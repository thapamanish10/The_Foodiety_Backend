

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.loading-screen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="container-heading container-heading-section">
            <h3>User Management: Total Users: <?php echo e($users->count()); ?></h3>
        </div>
        <div class="table">
            <table>
                <thead>
                    <tr>
                        <td>Sn.</td>
                        <td>Name</td>
                        <td>Email</td>
                        <td>Role</td>
                        <td>Action <ion-icon name="ellipsis-vertical"></ion-icon></td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <div class="form-group index-form-group">
                                    <?php if(auth()->user()->isSuperAdmin()): ?>
                                        <form action="<?php echo e(route('users.update-role', $user)); ?>" method="POST" id="blogForm">
                                            <?php echo csrf_field(); ?>
                                            <select name="role" class="form-select" onchange="this.form.submit()">
                                                <option value="super_admin"
                                                    <?php echo e($user->role === 'super_admin' ? 'selected' : ''); ?>>
                                                    Super
                                                    Admin</option>
                                                <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Admin
                                                </option>
                                                <option value="user" <?php echo e($user->role === 'user' ? 'selected' : ''); ?>>User
                                                </option>
                                            </select>
                                        </form>
                                    <?php else: ?>
                                        <?php echo e(ucfirst($user->role)); ?>

                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <?php if(auth()->user()->isAdmin()): ?>
                                    <a href="<?php echo e(route('users.reset-password', $user)); ?>"class="btn btn-outline-primary"><img
                                            src="<?php echo e(url('reset-password.png')); ?>" alt=""></a>
                                <?php endif; ?>
                                <?php if(auth()->user()->role === 'super_admin' && auth()->id() !== $user->id): ?>
                                    <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger"
                                            onclick="return confirm('Are you sure you want to delete this blog?')"><img
                                                src="<?php echo e(url('trash.png')); ?>" alt=""></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const form = document.getElementById('blogForm');
                const loadingOverlay = document.getElementById('loadingOverlay');
                const submitButton = document.getElementById('submitButton');

                form.addEventListener('submit', function(e) {
                    // Show loading spinner
                    loadingOverlay.style.display = 'flex';

                    // Disable submit button to prevent multiple submissions
                    if (submitButton) {
                        submitButton.disabled = true;
                        submitButton.innerHTML = 'Processing...';
                    }
                });
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/users/index.blade.php ENDPATH**/ ?>