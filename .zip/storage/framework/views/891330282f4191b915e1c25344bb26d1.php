

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3 = $attributes; } ?>
<?php $component = App\View\Components\MainHeading::resolve(['title' => 'Recommended Restaurants'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainHeading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3)): ?>
<?php $attributes = $__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3; ?>
<?php unset($__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3)): ?>
<?php $component = $__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3; ?>
<?php unset($__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3); ?>
<?php endif; ?>
    <section class="restaurant-index-div">
        <?php if (isset($component)) { $__componentOriginal4f9d38156909c30c7bc179d14c0a96c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4 = $attributes; } ?>
<?php $component = App\View\Components\MainSubHeading::resolve(['type' => 'blog'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-sub-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainSubHeading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'All My Blogs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4)): ?>
<?php $attributes = $__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4; ?>
<?php unset($__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f9d38156909c30c7bc179d14c0a96c4)): ?>
<?php $component = $__componentOriginal4f9d38156909c30c7bc179d14c0a96c4; ?>
<?php unset($__componentOriginal4f9d38156909c30c7bc179d14c0a96c4); ?>
<?php endif; ?>
        <?php $__empty_1 = true; $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if (isset($component)) { $__componentOriginal61fdfc30939fecb8fcf384ac5e8614cd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal61fdfc30939fecb8fcf384ac5e8614cd = $attributes; } ?>
<?php $component = App\View\Components\RestaurantCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('restaurant-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\RestaurantCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['restaurant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($restaurant),'views' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($restaurant->views_count),'comments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($restaurant->comments_count),'likes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($restaurant->likes_count)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal61fdfc30939fecb8fcf384ac5e8614cd)): ?>
<?php $attributes = $__attributesOriginal61fdfc30939fecb8fcf384ac5e8614cd; ?>
<?php unset($__attributesOriginal61fdfc30939fecb8fcf384ac5e8614cd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal61fdfc30939fecb8fcf384ac5e8614cd)): ?>
<?php $component = $__componentOriginal61fdfc30939fecb8fcf384ac5e8614cd; ?>
<?php unset($__componentOriginal61fdfc30939fecb8fcf384ac5e8614cd); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <span class="no-restaurants">No blogs found</span>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<style>
    .restaurant-index-div {
        width: 55%;
        margin: auto;
    }

    .no-restaurants {
        display: block;
        text-align: center;
        padding: 2rem;
        color: #5f5f5f;
    }

    @media (max-width: 1200px) {
        .restaurant-index-div {
            width: 55%;
            margin: auto;
        }
    }

    @media (max-width: 900px) {
        .restaurant-index-div {
            width: 55%;
            margin: auto;
        }
    }

    @media (max-width: 600px) {
        .restaurant-index-div {
            width: 100%;
            margin: auto;
        }
    }
</style>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/Frontend/restaurants/index.blade.php ENDPATH**/ ?>