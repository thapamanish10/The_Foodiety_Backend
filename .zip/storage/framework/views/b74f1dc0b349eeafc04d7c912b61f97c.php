<?php if($errors->any()): ?>
    <div class="alert alert-danger" id="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert danger ">
                    <img src="<?php echo e(asset('dashboardicons/error.png')); ?>" alt="ErrorIcon">
                    <div class="alertMessage">
                        <h3>Error!</h3>
                        <span><?php echo e($error); ?>.</span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success" id="alert">
        <div class="alert success">
            <img src="<?php echo e(asset('dashboardicons/success.png')); ?>" alt="SuccessIcon">
            <div class="alertMessage">
                <h3>Success!</h3>
                <span><?php echo e(session('success')); ?>.</span>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php $__env->startSection('alertScript'); ?>
    <script>
    // Show the alert
        document.addEventListener('DOMContentLoaded', function() {
            const alertElement = document.getElementById('alert');

            // Hide the alert after 6 seconds
            setTimeout(() => {
                alertElement.classList.add('hide');
            }, 6000);
        });
    </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/layouts/alert.blade.php ENDPATH**/ ?>