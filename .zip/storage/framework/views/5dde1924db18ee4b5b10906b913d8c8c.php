<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['gallery', 'link']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['gallery', 'link']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="gallery-main-div-card-body-image-card">
    <a href="<?php echo e($link); ?>"></a>
    <img src="<?php echo e(asset('storage/' . $gallery->image)); ?>" alt="<?php echo e($gallery->name); ?>">
    <div class="gallery-main-div-card-body-image-card-info">
        <h3><?php echo e($gallery->name); ?></h3>
        <p>View <?php echo e($gallery->description); ?></p>
    </div>
</div>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap');

    .gallery-main-div-card-body-image-card {
        flex: 1;
        width: 450px;
        min-width: 450px;
        max-width: 450px;
        height: 450px;
        min-height: 450px;
        max-height: 450px;
        overflow: hidden;
        cursor: pointer;
        position: relative;
    }

    .gallery-main-div-card-body-image-card a {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 1;
    }

    .gallery-main-div-card-body-image-card img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center;
        background: linear-gradient(180deg, rgba(38, 39, 39, 0), rgba(31, 31, 31, 0.8));
    }

    .gallery-main-div-card-body-image-card:hover .gallery-main-div-card-body-image-card-info {
        bottom: 0;
    }

    .gallery-main-div-card-body-image-card-info {
        width: 100%;
        position: absolute;
        bottom: -130px;
        left: 0;
        padding: 2rem;
        background: linear-gradient(180deg, #26272700, #1f1f1fcb);
        transition: 0.6s ease-in-out;
    }

    .gallery-main-div-card-body-image-card-info h3 {
        font-size: 18px;
        font-family: "Playfair Display", serif;
        font-style: italic;
        font-weight: 400;
        color: #ffffff;
        z-index: 2;
    }

    .gallery-main-div-card-body-image-card-info p {
        font-size: 14px;
        font-family: "Playfair Display", serif;
        font-style: italic;
        color: #ffffff;
        text-decoration: none;
        z-index: 2;
    }

    @media (max-width: 600px) {
        .gallery-main-div-card-body-image-card {
            flex: 1;
            height: 200px;
            min-height: 200px;
            max-height: 200px;
            overflow: hidden;
            cursor: pointer;
            position: relative;
        }
    }
</style>
<?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/components/gallary-card.blade.php ENDPATH**/ ?>