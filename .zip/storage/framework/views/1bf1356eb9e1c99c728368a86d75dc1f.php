


<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3 = $attributes; } ?>
<?php $component = App\View\Components\MainHeading::resolve(['title' => 'Foodiety Blogs'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainHeading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3)): ?>
<?php $attributes = $__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3; ?>
<?php unset($__attributesOriginal3e26d57fd82960e7e3dfbd994d6720f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3)): ?>
<?php $component = $__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3; ?>
<?php unset($__componentOriginal3e26d57fd82960e7e3dfbd994d6720f3); ?>
<?php endif; ?>

    
    <section class="blog-index-div">
        <?php if (isset($component)) { $__componentOriginal4f9d38156909c30c7bc179d14c0a96c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4 = $attributes; } ?>
<?php $component = App\View\Components\MainSubHeading::resolve(['type' => 'blog'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-sub-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainSubHeading::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'All My Blogs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4)): ?>
<?php $attributes = $__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4; ?>
<?php unset($__attributesOriginal4f9d38156909c30c7bc179d14c0a96c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f9d38156909c30c7bc179d14c0a96c4)): ?>
<?php $component = $__componentOriginal4f9d38156909c30c7bc179d14c0a96c4; ?>
<?php unset($__componentOriginal4f9d38156909c30c7bc179d14c0a96c4); ?>
<?php endif; ?>
            <div class="blog-filter-container">
                <form method="GET" action="<?php echo e(route('home.blogs.index')); ?>" id="categoryFilterForm">
                    <div class="category-checkboxes">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-checkbox">
                                <input type="checkbox" 
                                    id="category-<?php echo e($category->id); ?>"
                                    name="categories[]" 
                                    value="<?php echo e($category->slug); ?>"
                                    <?php echo e(in_array($category->slug, request('categories', [])) ? 'checked' : ''); ?>

                                    onchange="document.getElementById('categoryFilterForm').submit()"
                                    class="custom-checkbox-input">
                                <label for="category-<?php echo e($category->id); ?>" class="custom-checkbox-label">
                                    <span class="custom-checkbox-text"><?php echo e($category->name); ?></span>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(request('categories')): ?>
                            <a href="<?php echo e(route('home.blogs.index')); ?>"  class="custom-checkbox-label">
                                Clear All
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if (isset($component)) { $__componentOriginal52461c287b13c13ee0ec855aeb410839 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52461c287b13c13ee0ec855aeb410839 = $attributes; } ?>
<?php $component = App\View\Components\Card2::resolve(['blog' => $blog,'views' => $blog->views_count,'comments' => $blog->comments_count] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card2::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['likes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blog->likes_count)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52461c287b13c13ee0ec855aeb410839)): ?>
<?php $attributes = $__attributesOriginal52461c287b13c13ee0ec855aeb410839; ?>
<?php unset($__attributesOriginal52461c287b13c13ee0ec855aeb410839); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52461c287b13c13ee0ec855aeb410839)): ?>
<?php $component = $__componentOriginal52461c287b13c13ee0ec855aeb410839; ?>
<?php unset($__componentOriginal52461c287b13c13ee0ec855aeb410839); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <span class="no-blogs">No blogs found</span>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap');
    .blog-index-div {
        width: 55%;
        margin: auto;
    }

    .no-blogs {
        display: block;
        text-align: center;
        padding: 2rem;
        color: #5f5f5f;
    }

    .blog-filter-container {
        border-radius: 8px;
        flex-wrap: wrap;
    }

    .filter-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }

    .filter-header h3 {
        margin: 0;
        font-size: 18px;
        color: #333;
    }

    .clear-filter {
        color: #e74c3c;
        text-decoration: none;
        font-size: 14px;
    }

    .clear-filter:hover {
        text-decoration: underline;
    }

    .category-checkboxes {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin-bottom: 2rem;
    }

    .custom-checkbox {
        position: relative;
    }

    .custom-checkbox-input {
        position: absolute;
        opacity: 0;
        width: 0;
        height: 0;
    }

    .custom-checkbox-label {
        display: inline-block;
        padding: .5rem 1.5rem;
        border-top: 1px solid #bebebe28;
        border-left: 1px solid #bebebe28;
        border-right: 1px solid #bebebe28;
        border-bottom: 2px solid #bebebe28;
        background-color:  transparent;
        color: #5f5f5f;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        user-select: none;
        text-decoration: none;
        font-family: "Playfair Display", serif;
        white-space: nowrap;
        border-radius: .4rem;
    }

    .custom-checkbox-input:checked + .custom-checkbox-label {
        color: #5f5f5f;
        border-bottom: 2px solid #ffde59;
    }

    .custom-checkbox-label:hover {
        border-bottom: 2px solid #ffde59;
    }

    .custom-checkbox-input:checked + .custom-checkbox-label:hover {
        border-bottom: 2px solid #ffde59;
    }
    @media (max-width: 1200px) {
        .blog-index-div {
            width: 55%;
            margin: auto;
        }
    }

    @media (max-width: 900px) {
        .blog-index-div {
            width: 55%;
            margin: auto;
        }
    }

    @media (max-width: 600px) {
        .blog-index-div {
            width: 100%;
            margin: auto;
        }
        .blog-filter-container {
            width: 100%;
            padding: auto;
            border-radius: 8px;
        }
        .category-checkboxes {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            padding: 15px;
            gap: 5px;
        }
    }
</style>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/Frontend/blogs/index.blade.php ENDPATH**/ ?>