

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.loading-screen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="container-heading">
            <h3>Fill up the Information:</h3>
            <p>Edit information about the blog post.</p>
        </div>
        <form action="<?php echo e(route('blogs.update', $blog->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name" class="form-label">Title</label>
                <input type="text" class="form-control" id="name" name="name"
                    value="<?php echo e(old('name', $blog->name)); ?>" required>
            </div>
            <div class="form-group">
                <label for="desc" class="form-label">Content</label>
                <textarea class="form-control" id="editor" name="desc" rows="5" required><?php echo e(old('desc', $blog->desc)); ?></textarea>
            </div>
            <div class="form-group">
                <label for="desc2" class="form-label">Content 2</label>
                <textarea class="form-control" id="editor1" name="desc2" rows="5" required><?php echo e(old('desc2', $blog->desc2)); ?></textarea>
            </div>
            <label for="images" class="form-label">Blog Images</label>
            <div class="form-group-image">
                <input type="file" class="form-control" id="images" name="images[]" multiple accept="image/*"
                    style="display: none;">
                <div id="imagePreviews" class="mt-2 d-flex flex-wrap gap-2"></div>
                <div class="image-upload-icon" onclick="document.getElementById('images').click();">
                    <img src="<?php echo e(asset('assets/upload.png')); ?>" class="uploadimage" alt="" id="customButton">
                    <span id="fileName">Drop your image here, Or browse</span>
                </div>
            </div>
            <div class="form-text" style="padding: 5px 0;">Max size 100MB each (JPEG, PNG, JPG, GIF, WEBP)</div>
            <div class="row">
                <div class="form-group">
                    <label for="publish_at" class="form-label">Publish Date</label>
                    <input type="datetime-local" class="form-control" id="publish_at" name="publish_at"
                        value="<?php echo e(old('publish_at', $blog->publish_at)); ?>" required>
                </div>
                <div class="form-group">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="public" <?php echo e($blog->status === 'public' ? 'selected' : ''); ?>>Public</option>
                        <option value="private" <?php echo e($blog->status === 'private' ? 'selected' : ''); ?>>Private</option>
                        <option value="draft" <?php echo e($blog->status === 'draft' ? 'selected' : ''); ?>>Draft</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Categories (optional)</label>
                <div class="category-checkboxes">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="custom-checkbox">
                            <input type="checkbox" id="category-<?php echo e($category->id); ?>" name="categories[]"
                                value="<?php echo e($category->id); ?>"
                                <?php echo e($blog->categories->contains($category->id) ? 'checked' : ''); ?>

                                class="custom-checkbox-input">
                            <label for="category-<?php echo e($category->id); ?>" class="custom-checkbox-label">
                                <span class="custom-checkbox-button"></span>
                                <span class="custom-checkbox-text"><?php echo e($category->name); ?></span>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="form-group-buttons">
                <a href="<?php echo e(route('blogs.index')); ?>" class=" btn-secondary">Cancel</a>
                <button type="submit" class=" btn-primary">Update Blog</button>
            </div>
        </form>

        <label class="form-label">Current Images</label>
        <div class="current-images" >
            <?php $__currentLoopData = $blog->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="image-container position-relative" data-image-id="<?php echo e($image->id); ?>">
                    <img src="<?php echo e(asset('storage/' . $image->path)); ?>" width="150" height="150" alt="Current Thumbnail"
                    style="object-fit: cover">
                    <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 remove-image"
                        data-image-id="<?php echo e($image->id); ?>" title="Remove image">
                        <i class="fas fa-times"></i>
                    </button>
                    <input type="hidden" name="existing_images[]" value="<?php echo e($image->id); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const imageInput = document.getElementById('images');
            const previewContainer = document.getElementById('imagePreviews');
            const maxFiles = 5; // Set maximum number of images
            let selectedFiles = [];

            // Handle file selection
            imageInput.addEventListener('change', function(e) {
                const files = Array.from(e.target.files);

                // Check total files won't exceed max
                if (selectedFiles.length + files.length > maxFiles) {
                    alert(`You can upload a maximum of ${maxFiles} images`);
                    return;
                }

                files.forEach(file => {
                    // Validate file type and size
                    if (!file.type.match('image.*')) {
                        alert(`${file.name} is not an image file`);
                        return;
                    }

                    // 20MB in bytes (20 * 1024 * 1024)
                    if (file.size > 20971520) {
                        alert(`${file.name} is too large (max 20MB)`);
                        return;
                    }

                    // Add to selected files
                    selectedFiles.push(file);

                    // Create preview
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const preview = document.createElement('div');
                        preview.className = 'image-preview position-relative';
                        preview.style.width = '150px';

                        preview.innerHTML = `
                            <img src="${e.target.result}" class="img-thumbnail" alt="Preview">
                            <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 m-1 remove-image">
                            <img src="<?php echo e(url('close.png')); ?>"/>
                            </button>
                        `;

                        previewContainer.appendChild(preview);

                        // Add remove functionality
                        preview.querySelector('.remove-image').addEventListener('click',
                            function() {
                                preview.remove();
                                selectedFiles = selectedFiles.filter(f => f !== file);
                                updateFileInput();
                            });
                    };
                    reader.readAsDataURL(file);
                });

                updateFileInput();
            });

            // Update the actual file input with remaining files
            function updateFileInput() {
                const dataTransfer = new DataTransfer();
                selectedFiles.forEach(file => dataTransfer.items.add(file));
                imageInput.files = dataTransfer.files;
            }
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('blogForm');
            const loadingOverlay = document.getElementById('loadingOverlay');
            const submitButton = document.getElementById('submitButton');

            form.addEventListener('submit', function(e) {
                // Show loading spinner
                loadingOverlay.style.display = 'flex';

                // Disable submit button to prevent multiple submissions
                if (submitButton) {
                    submitButton.disabled = true;
                    submitButton.innerHTML = 'Processing...';
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ckScript'); ?>
    <script>
        ClassicEditor
            .create(document.querySelector('#editor'))
            .catch(error => {
                console.error(error);
            });
    </script>
    <script>
        ClassicEditor
            .create(document.querySelector('#editor1'))
            .catch(error => {
                console.error(error);
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/pages/blog/edit.blade.php ENDPATH**/ ?>