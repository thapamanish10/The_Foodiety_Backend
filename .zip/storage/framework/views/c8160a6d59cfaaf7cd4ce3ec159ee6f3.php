<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['blog', 'views', 'comments', 'likes', 'type']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['blog', 'views', 'comments', 'likes', 'type']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="card">
    <a
        href="<?php echo e($type === 'restaurant'
            ? route('home.recipes.show', ['recipe' => $blog->id . '-0-' . Str::slug($blog->name)])
            : route('home.blogs.show', ['blog' => $blog->id . '-0-' . Str::slug($blog->name)])); ?>">
    </a>
    <div class="card-image">
        <?php
            $imageToShow = $blog->images->first();
            $defaultImage = $type === 'recipe' ? 'default-recipe.jpg' : 'default-blog.jpg';
            $storageFolder = $type === 'recipe' ? 'recipe_images' : 'blog_images';
        ?>

        <?php if($imageToShow && Storage::exists('public/' . $storageFolder . '/' . basename($imageToShow->path))): ?>
            <img src="<?php echo e(Storage::url($storageFolder . '/' . basename($imageToShow->path))); ?>" alt="<?php echo e($blog->name); ?>"
                class="blog-image" loading="lazy">
        <?php else: ?>
            <img src="<?php echo e(asset('images/' . $defaultImage)); ?>" alt="<?php echo e($blog->name); ?>" class="blog-image">
        <?php endif; ?>
    </div>
    <h3 class="card-heading"><?php echo e($blog->name); ?></h3>
    <div class="card-info">
        <div class="card-info-sec">
            <div class="card-info-sub-sec">
                <img src="<?php echo e(url('/view.png')); ?>" alt="">
                <span><?php echo e($views->count()); ?></span>
            </div>
            <div class="card-info-sub-sec">
                <img src="<?php echo e(url('/message.png')); ?>" alt="">
                <span><?php echo e($comments->count()); ?></span>
            </div>
        </div>
        <div class="card-info-sec">
            <form action="<?php echo e($type === 'recipe' ? route('recipes.like', $blog) : route('blogs.like', $blog)); ?>"
                method="POST" class="like-form">
                <?php echo csrf_field(); ?>
                <button type="submit" class="like-button <?php echo e($blog->isLikedBy(auth()->user()) ? 'liked' : ''); ?>">
                    <div class="card-info-sub-sec">
                        <span><?php echo e($likes->count()); ?></span>
                        <img src="<?php echo e(asset($blog->isLikedBy(auth()->user()) ? 'heart (2).png' : 'heart (1).png')); ?>"
                            alt="Like">
                    </div>
                </button>
            </form>
        </div>
    </div>
</div>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap');

    .card-info-sec button {
        background: transparent;
        border: 0;
        outline: 0;
        cursor: pointer;
    }

    .card {
        position: relative;
        flex: 1 1 300px;
        min-height: 350px;
        height: 350px;
        max-height: 350px;
        border: 1px solid #dddddd93;
        display: flex;
        flex-direction: column;

    }

    .card a {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 60%;
    }

    .card-image {
        width: 100%;
        height: 60%;
        overflow: hidden;
    }

    .card-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .card-heading {
        width: 90%;
        margin: auto;
        padding: 1rem 0;
        font-family: "Playfair Display", serif;
        font-style: italic;
        font-weight: 400;
        color: #5f5f5f;
    }

    .card-info {
        width: 90%;
        position: relative;
        margin: auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-top: 1px solid #dddddd93;
        padding: 1rem 0;
    }

    .card-info-sec {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .card-info-sub-sec {
        display: flex;
        align-items: center;
        gap: .5rem;
    }

    .card-info-sub-sec img {
        width: 18px;
        height: 18px;
        object-fit: cover;
    }

    .card-info-sub-sec span {
        font-size: 15px;
        font-weight: normal;
        color: #5f5f5f;
    }
</style>
<?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/components/card.blade.php ENDPATH**/ ?>