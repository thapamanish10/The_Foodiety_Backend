

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="container-heading container-heading-section">
            <h3>Blog Posts:</h3>
            <div class="form-group-buttons">
                <a href="<?php echo e(route('blogs.create')); ?>" class="create-btn"><strong style="margin-right: .5rem">+ </strong>
                    Create Blogs</a>
            </div>
        </div>

        <div class="table">
            <table>
                <thead>
                    <tr>
                        <td>Sn.</td>
                        <td>BLog Title</td>
                        <td>BLog Image</td>
                        <td>BLog Desc</td>
                        <td>Publish Date</td>
                        <td>Status</td>
                        <td>Type</td>
                        <td>Action <ion-icon name="ellipsis-vertical"></ion-icon></td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($blog->name); ?></td>
                            <td>
                                <?php if($blog->images->count() > 0): ?>
                                    <?php $__currentLoopData = $blog->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(file_exists(public_path('storage/' . $image->path))): ?>
                                            <img class="blogLogo" src="<?php echo e(asset('storage/' . $image->path)); ?>"
                                                alt="Blog Image" width="40">
                                        <?php else: ?>
                                            <img class="blogLogo" src="<?php echo e(asset('images/default-blog-image.jpg')); ?>"
                                                alt="Default Blog Image" width="40">
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <img class="blogLogo" src="<?php echo e(asset('images/default-blog-image.jpg')); ?>"
                                        alt="Default Blog Image" width="40">
                                <?php endif; ?>
                            </td>
                            <td><?php echo Str::limit($blog->desc, 60); ?></td>
                            <td> <?php echo e($blog->publish_at->format('M d, Y')); ?></td>
                            <td>
                                <?php if($blog->status === 'public'): ?>
                                    <img class="show-hide-icon show-image" src="<?php echo e(url('show.png')); ?>" alt="">
                                <?php else: ?>
                                    <img class="show-hide-icon hide-image" src="<?php echo e(url('hide.png')); ?>" alt="">
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $blog->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-primary"><?php echo e($category->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><a href="<?php echo e(route('blogs.show', $blog->id)); ?>" class="btn btn-outline-primary"><img
                                        src="<?php echo e(url('show.png')); ?>" alt=""></a>
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('blogs.edit', $blog->id)); ?>" class="btn btn-outline-secondary"><img
                                            src="<?php echo e(url('edit.png')); ?>" alt=""></a>
                                    <form action="<?php echo e(route('blogs.destroy', $blog->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger"
                                            onclick="return confirm('Are you sure you want to delete this blog?')"><img
                                                src="<?php echo e(url('trash.png')); ?>" alt=""></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/pages/blog/index.blade.php ENDPATH**/ ?>