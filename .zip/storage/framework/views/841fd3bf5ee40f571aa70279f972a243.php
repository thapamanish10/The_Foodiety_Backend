

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="container-heading container-heading-section">
            <h3>Videos Info:</h3>
            <div class="form-group-buttons">
                <a href="<?php echo e(route('videos.create')); ?>" class="create-btn"><strong style="margin-right: .5rem">+ </strong>Create
                    Videos</a>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="table">
            <table>
                <thead>
                    <tr>
                        <td>Sn.</td>
                        <td>Name</td>
                        <td>Thumbnail</td>
                        <td>Desc</td>
                        <td>Created at</td>
                        <td>Action <ion-icon name="ellipsis-vertical"></ion-icon></td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($video->name); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/' . $video->thumbnail_path)); ?>" class="blogLogo"
                                    alt="<?php echo e($video->name); ?>" width="40">
                            </td>
                            <td><?php echo Str::limit($video->desc, 60); ?></td>
                            <td> <?php echo e($video->created_at->format('M d, Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('videos.show', $video)); ?>" class="btn btn-outline-primary"><img
                                        src="<?php echo e(url('show.png')); ?>" alt=""></a>
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('videos.edit', $video)); ?>" class="btn btn-outline-secondary"><img
                                            src="<?php echo e(url('edit.png')); ?>" alt=""></a>
                                    <form action="<?php echo e(route('videos.destroy', $video)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger"
                                            onclick="return confirm('Are you sure you want to delete this video?')"><img
                                                src="<?php echo e(url('trash.png')); ?>" alt=""></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/videos/index.blade.php ENDPATH**/ ?>