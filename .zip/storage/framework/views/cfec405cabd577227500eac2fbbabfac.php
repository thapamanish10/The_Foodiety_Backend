<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Foodiety'); ?></title>
    <link rel="icon" href="<?php echo e(asset('assets/foodiety.png')); ?>" type="image/png">
    <!-- Other head elements -->
    <link rel="stylesheet" href="<?php echo e(asset('./css/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/dashboard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/buttons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/totalitems.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/topbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/sidebar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/products.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/profile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/single.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/location.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/details.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/business.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/alert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/message.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/global-form.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./css/global-table.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
</head>

<body>
    <main class="home">
        <div class="left">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="right">
            <div class="top">
                <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="content">
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Restore scroll position
                    const scrollPosition = sessionStorage.getItem('scrollPosition');
                    if (scrollPosition) {
                        requestAnimationFrame(() => {
                            window.scrollTo(0, parseInt(scrollPosition));
                            sessionStorage.removeItem('scrollPosition');
                        });
                    }
        
                    // Debounce function to limit how often we save position
                    let saveScrollTimeout;
                    const saveScrollPosition = () => {
                        clearTimeout(saveScrollTimeout);
                        saveScrollTimeout = setTimeout(() => {
                            sessionStorage.setItem('scrollPosition', window.scrollY || window.pageYOffset);
                        }, 100);
                    };
        
                    // Save position on scroll
                    window.addEventListener('scroll', saveScrollPosition);
        
                    // Save final position before leaving
                    window.addEventListener('beforeunload', saveScrollPosition);
                });
            </script>
            <div class="footer">
                <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('ckScript'); ?>
                <?php echo $__env->yieldContent('jsScript'); ?>
                <?php echo $__env->yieldContent('alertScript'); ?>
                <?php echo $__env->yieldContent('displayImageScript'); ?>
                <?php echo $__env->yieldContent('carouselScript'); ?>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/pages/home.blade.php ENDPATH**/ ?>