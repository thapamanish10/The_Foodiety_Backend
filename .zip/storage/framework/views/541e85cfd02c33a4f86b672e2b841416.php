

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="container-heading container-heading-section">
            <h3>Gallery Images:</h3>
            <div class="form-group-buttons">
                <a href="<?php echo e(route('galleries.create')); ?>" class="create-btn"><strong style="margin-right: .5rem">+
                    </strong>Create Images</a>
            </div>
        </div>

        <div class="table">
            <table>
                <thead>
                    <tr>
                        <td>Sn.</td>
                        <td>Name</td>
                        <td>Image</td>
                        <td>Desc</td>
                        <td>Created at</td>
                        <td>Action <ion-icon name="ellipsis-vertical"></ion-icon></td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($gallery->name); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/' . $gallery->image)); ?>" class="blogLogo"
                                    alt="<?php echo e($gallery->name); ?>" width="40">
                            </td>
                            <td><?php echo Str::limit($gallery->description, 60); ?></td>
                            <td> <?php echo e($gallery->created_at->format('M d, Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('galleries.show', $gallery)); ?>" class="btn btn-outline-primary"><img
                                        src="<?php echo e(url('show.png')); ?>" alt=""></a>
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('galleries.edit', $gallery)); ?>" class="btn btn-outline-secondary"><img
                                            src="<?php echo e(url('edit.png')); ?>" alt=""></a>
                                    <form action="<?php echo e(route('galleries.destroy', $gallery)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger"
                                            onclick="return confirm('Are you sure you want to delete this image?')"><img
                                                src="<?php echo e(url('trash.png')); ?>" alt=""></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/galleries/index.blade.php ENDPATH**/ ?>