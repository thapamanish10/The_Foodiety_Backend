<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>

<!-- Favicon -->
<link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">

<!-- Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

<!-- Styles -->


<?php echo $__env->yieldPushContent('styles'); ?><?php /**PATH C:\Users\Manish\Desktop\_FOODIETY\foodiety_backend\resources\views/Frontend/layouts/head.blade.php ENDPATH**/ ?>