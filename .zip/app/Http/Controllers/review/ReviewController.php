<?php

namespace App\Http\Controllers\review;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    //
    public function show($id)
    {
        // $product = Product::with('reviews')->findOrFail($id);
        // return view('products.show', compact('product'));
    }

}
