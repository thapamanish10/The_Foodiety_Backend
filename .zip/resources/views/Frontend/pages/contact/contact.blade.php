@extends('Frontend.layouts.main')

@section('content')
    @include('Frontend.pages.contact.index')
@endsection
